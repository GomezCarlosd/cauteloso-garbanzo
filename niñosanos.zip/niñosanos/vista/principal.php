<html>
<?php require_once("comunes/encabezado.php"); ?>
<body> 
    <?php require_once('comunes/menu.php');     
    ?>
    <!-- Clase container todo debe ir dentro de contenedor -->
    <!-- div pagina principal -->
    <div id="hero">
        <div class="container">
            <div class="contenido" >
                <h1>Ambulatorio de Pueblo Nuevo</h1>
                <h2>Consulta de Niños Sanos</h2>
                <p><b>"Todo niño tiene derecho a un sistema de salud digno y gratuito."</b></p>
            </div>

        </div> 

        <!-- Fin de clase container -->
        <!-- espacio -->
        <div class="container-fluid">
            <div class="row"> <div class="col-lg-12 py-3"></div> </div>


            <!-- Contenido -->
            <main role="main">
                <div class="container marketing text-center card card-container" style="background-color: rgba(245, 245, 245, 0.4);">
                    <div class="row">
                      <div class="col-lg-4">
                          <img class="rounded-circle" src="./img/mision.jpg" alt="Generic placeholder image" width="140" height="140">
                          <h2>MISION</h2>
                          <p>El Ambulatorio Urbano II Pueblo Nuevo tiene como labor cooperar con la población de la comunidad dePueblo Nuevo en logar una mejor calidad de vida, su bienestar colectivo en los nivelesBio-psicosocial, con acciones que permitan el acceso a los servicios de manera integral, para que en conjunto con el equipo de salud y comunidad, puedan satisfacer sus necesidades.</p>
                          
                      </div><!-- /.col-lg-4 -->
                      <div class="col-lg-4">
                        <img class="rounded-circle" src="./img/vision.jpg" alt="Generic placeholder image" width="140" height="140">
                        <h2>VISION</h2>
                        <p>El equipo de salud del AMBUALTORIO Urbano II Pueblo Nuevo se percibe encaminado a integrarse a la comunidad de Pueblo Nuevo, a la toma de decisiones, también en la planificación, ejecución y control de políticas de salud especificas, adaptadas a la realidad de la comunidad, para alcanzar una verdadera atención integral del individuo, la familia y la comunidad.</p>
                        
                    </div><!-- /.col-lg-4 -->
                    <div class="col-lg-4">
                        <img class="rounded-circle" src="./img/accion.jpg" alt="Generic placeholder image" width="140" height="140">
                        <h2>ACCIÓN</h2>
                        <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
                        
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->

            </main>      
        </div>

        <hr>
        <!-- Pie de la pagina -->
        <footer id="footer">
            <div class="container">
                <div class="col-md-12 text-center">
                    <p><small>&copy; Todos los derechos reservados </small> 
                        <br><small>Hecho por Angel Delgado, Carlos Gomez, Naudys Torrealba, Yeisson Colmenarez</small></p> 
                    </div>
                </div>
            </footer>


        </body>
        </html>