<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body class="contenedor">
	<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->

	<?php require_once("comunes/slidebar.php"); ?>

	<div id="contenidomed">
		<div class="card card-container">
			<div class="card-header">
				<div class="container text-center h2 text-black-50">
					Registrar Paciente
				</div>
			</div>
			<form method="post" action="" id="f">
				<!--Caja de entrada invisible para indicar al servidor que boton fue pulsado-->
				<input type="text" name="accion" id="accion" style="display:none"/>
				<div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->

					<div class="row">
						<div class="col">
							<label for="nhmedico">Historial Médico</label>
							<input class="form-control" type="text" id="nhmedico" name="nhmedico" 
							pattern="[0-9]{5,7}"
							required 
							maxlength="7" 
							minlength="5" 
							title="Solo numeros entre 5 y 7"/>
							<span id="snhmedico"></span>
						</div>

						<div class="col">
							<label for="nombre">Nombre</label>
							<input class="form-control" type="text" id="nombre" name="nombre"
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}" 
							required 
							maxlength="15" 
							minlength="3" 
							title="Solo letras entre 3 y 15 caracteres"/>
							<span id="snombre"></span>
						</div>

						<div class="col">
							<label for="apellido">Apellido</label>
							<input class="form-control" type="text" id="apellido" name="apellido" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}" 
							required 
							maxlength="15" 
							minlength="3" 
							title="Solo letras entre 3 y 15 caracteres"/>
							<span id="sapellido"></span>
						</div>
					</div>

					<div class="row">
						
						<div class="col">
							<label for="direccion">Direccion</label>
							<input class="form-control" type="text" id="direccion" name="direccion" 
							pattern="[A-Za-z0-9,#\b\s\u00f1\u00d1\u00E0-\u00FC-]{6,35}" 
							required 
							maxlength="35" 
							minlength="6" 
							title="Solo letras y/o numeros entre 6 y 35 caracteres"/>
							<span id="sdireccion"></span>
						</div>
					</div>

					<div class="row">
						
						<div class="col">
							<label for="fechanacimiento">Fecha nacimiento</label>
							<input class="form-control" type="date" id="fechanacimiento" name="fechanacimiento" 
							min="2007-01-01" 
							required
							title="Introducir una fecha valida"/>
							<span id="sfechanaciemiento"></span>
						</div>

						<div class="col">
							<label for="pesonacimiento">Peso de nacimiento</label>
							<input class="form-control" type="text" id="fechanacimiento" name="pesonacimiento" 
							pattern="[0-9]{2}[A-Za-z]{2}{2,4}" 
							required
							maxlength="4" 
							minlength="2" 
							title="Introducir un peso valido Ej. 10kg"/>
							<span id="spesonacimiento"></span>
						</div>

						<div class="col">
							<label for="estnacimiento">Estatura de nacimiento</label>
							<input class="form-control" type="text" id="estnacimiento" name="estnacimiento"  
							pattern="[0-9]{3}[A-Za-z]{2}{3,5}" 
							required
							maxlength="5" 
							minlength="3" 
							title="Introducir una estatura valida Ej. 40cm"/>
							<span id="sestnacimiento"></span>
						</div>
					</div>

					<div class="row">

						<div class="col">
							<label for="desarrollopsi">Desarrollo Psicomotor</label>
							<input class="form-control" type="text" id="desarrollopsi" name="desarrollopsi" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{7,20}" 
							required
							maxlength="20" 
							minlength="7" 
							title="Introducir la descripción psicomotor del paciente"/>
							<span id="sdesarrollopsi"></span>
						</div>

						<div class="col">
							<label for="antecnopato">Antecendentes personales no patológicos</label>
							<input class="form-control" type="text" id="antecnopatoi" name="antecnopato" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{7,20}" 
							required
							maxlength="20" 
							minlength="7" 
							title="Introducir antecedentes no patológicos del paciente"/>
							<span id="santecnopato"></span>
						</div>

						<div class="col">
							<label for="cedularep">Cedula del repesentante</label>
							<input class="form-control" type="text" id="cedularep" name="cedularep" 
							pattern="[VE]{1}[-]{1}[0-9]{7,8}" 
							required 
							maxlength="10" 
							minlength="3" 
							title="El formato debe ser V-9999999 o E-9999999"/>
							<span id="scedularep"></span>
						</div>	
					</div>

					<div class="row">
						<div class="col">
							<label for="antecfam">Antecendentes familiares del paciente</label>
							<input class="form-control" type="text" id="antecnopatoi" name="antecfam" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{12,50}" 
							required
							maxlength="50" 
							minlength="12" 
							title="Introducir antecedentes familiares del paciente"/>
							<span id="santecfam"></span>
						</div>

						<div class="col">
							<label for="antecheredo">Antecendentes heredo familiares</label>
							<input class="form-control" type="text" id="antecnopatoi" name="antecheredo" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{7,20}" 
							required
							maxlength="20" 
							minlength="7" 
							title="Introducir antecedentes heredo familiares del paciente"/>
							<span id="santecheredo"></span>
						</div>

						<div class="col">
							<label for="antecpre">Antecendentes prenatales</label>
							<input class="form-control" type="text" id="antecnopatoi" name="antecpre" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{7,20}" 
							required
							maxlength="20" 
							minlength="7" 
							title="Introducir antecedentes prenatales del paciente"/>
							<span id="santecpre"></span>
						</div>

						<div class="col">
							<label for="antecperi">Antecendentes perinatales</label>
							<input class="form-control" type="text" id="antecnopatoi" name="antecperi" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{7,20}" 
							required
							maxlength="20" 
							minlength="7" 
							title="Introducir antecedentes perinateles del paciente"/>
							<span id="santecperi"></span>
						</div>

						<div class="col">
							<label for="antecpost">Antecendentes postnatales</label>
							<input class="form-control" type="text" id="antecnopatoi" name="antecpost" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{7,20}" 
							required
							maxlength="20" 
							minlength="7" 
							title="Introducir antecedentes postnatales del paciente"/>
							<span id="santecpost"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<hr/>
						</div>
					</div>
				</div> <!-- fin del container -->

				<div class="card-footer text-muted"> <!-- inicio de los botones -->
						<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
				</div> <!-- fin de los botones -->
			</form>
			<div  class="container">
				<div class="row">
					<div class="col text-center">
						<?php
						if(!empty($mensaje)){
							echo $mensaje;
						}
						?>	
					</div>
				</div>
			</div>
		</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->
        
</body>

</html>