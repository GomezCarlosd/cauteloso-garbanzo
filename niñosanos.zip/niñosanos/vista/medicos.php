<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body class="contenedor">
	<!--Div oculta para colocar el mensaje a mostrar-->	
    <?php require_once("comunes/modal.php"); ?>
	<?php require_once("comunes/slidebar.php"); ?>

	<div id="contenidomed">
		<hr>
		<div class="card card-container">
			<div class="card-header">
				<div class="container text-center h2 text-black-50">
					Registro Medicos
				</div>
			</div>
			<form method="post" action="" id="f">
				<!--Caja de entrada invisible para indicar al servidor que boton fue pulsado-->
				<input type="text" name="accion" id="accion" style="display:none"/>
				<div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->

					<div class="row">
						<div class="col">
							<label for="cedula">Cedula</label>
							<input class="form-control" type="text" id="cedula" name="cedula" />
							<span id="scedula"></span>
						</div>

						<div class="col">
							<label for="nmedico">Número de Medico</label>
							<input class="form-control" type="text" id="nmedico" name="nmedico" />
							<span id="snmedico"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<label for="nombres">Nombre</label>
							<input class="form-control" type="text" id="nombres" name="nombres" />
							<span id="snombres"></span>
						</div>
						<div class="col">
							<label for="apellidos">Apellido</label>
							<input class="form-control" type="text" id="apellidos" name="apellidos" />
							<span id="sapellido"></span>
						</div>
					</div>

					<div class="row">

						<div class="col">
							<label for="fecingreso">Fecha de ingreso</label>
							<input class="form-control" type="date" id="fecingreso" name="fecingreso" min="1950-01-01" 
							required
							title="Introducir una fecha valida"/>
							<span id="sfecingreso"></span>
						</div>

						<div class="col">
							<label for="corre">Correo</label>
							<input class="form-control" type="text" id="correo" name="correo" 
							pattern="[A-Za-z_\u00f1\u00d1\u00E0-\u00FC-]{3,15}[@]{1}[A-Za-z0-9]{3,8}[.]{1}[A-Za-z]{2,3}" 
							maxlength="35" 
							minlength="6" 
							title="El formato debe ser alguien@servidor.com"/>
							<span id="scorreo"></span>
						</div>

						<div class="col">
							<label for="horario">Horario de trabajo</label>
							<select class="form-control" name="horario" id="horario" required/>
							<option selected> Diurno</option>
							<option>Nocturno</option>
							<span id="horario"></span>
						</select>
					</div>

				</div>

				<div class="row">
					<div class="col">
						<hr/>
					</div>
				</div>
			</div> <!-- fin del container -->

			<div class="card-footer text-muted"> <!-- inicio de los botones -->
					<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
			</div> <!-- fin de los botones -->
		</form> <!-- cierre del form botones -->

		<div  class="container">
			<div class="row">
				<div class="col text-center">
					<?php
					if(!empty($mensaje)){
						echo $mensaje;
					}
					?>	
				</div>
			</div>
		</div>
	</div> <!-- fin de container card -->
</div> <!-- fin del contenidomed -->
<script type="text/javascript" src="js/medicos.js"></script>
</body>
</html>