
$(document).ready(function(){

//Seccion para mostrar lo enviado en el modal mensaje//

//Función que verifica que exista algo dentro de un div
//oculto y lo muestra por el modal
if($.trim($("#mensajes").text()) != ""){
	muestraMensaje($("#mensajes").html());
}
//Fin de seccion de mostrar envio en modal mensaje//	
	
//VALIDACION DE DATOS	
	$("#cedula").on("keypress",function(e){
		validarkeypress(/^[VE0-9-\b]*$/,e);
	});
	
	$("#cedula").on("keyup",function(){
		validarkeyup(/^[VE]{1}[-]{1}[0-9]{7,8}$/,$(this),
		$("#scedula"),"El formato debe ser V-9999999 o E-9999999");
	});
	
	
	$("#apellidos").on("keypress",function(e){
		validarkeypress(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]*$/,e);
	});
	
	$("#apellidos").on("keyup",function(){
		validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}$/,
		$(this),$("#sapellidos"),"Solo letras entre 3 y 15 caracteres");
	});
	
	
	$("#nombres").on("keypress",function(e){
		validarkeypress(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]*$/,e);
	});
	
	$("#nombres").on("keyup",function(){
		validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}$/,
		$(this),$("#snombres"),"Solo letras entre 3 y 15 caracteres");
	});
	
	$("#direccion").on("keypress",function(e){
		validarkeypress(/^[A-Za-z0-9,#\b\s\u00f1\u00d1\u00E0-\u00FC-]*$/,e);
	});
	
	$("#direccion").on("keyup",function(){
		validarkeyup(/^[A-Za-z0-9,#\b\s\u00f1\u00d1\u00E0-\u00FC-]{6,35}$/,
		$(this),$("#sdireccion"),"Solo letras y/o numeros entre 6 y 35 caracteres");
	});
	
	
	$("#correo").on("keypress",function(e){
		validarkeypress(/^[A-Za-z@_.\b\u00f1\u00d1\u00E0-\u00FC-]*$/,e);
	});
	
	$("#correo").on("keyup",function(){
		validarkeyup(/^[A-Za-z_\u00f1\u00d1\u00E0-\u00FC-]{3,15}[@]{1}[A-Za-z0-9]{3,8}[.]{1}[A-Za-z]{2,3}$/,
		$(this),$("#scorreo"),"El formato debe ser alguien@servidor.com");
	});
	
	
	$("#nmedico").on("keypress",function(e){
		validarkeypress(/^[0-9\b-]*$/,e);
	});
	
	$("#nmedico").on("keyup",function(){
	    validarkeyup(/^[0-9]{4}[-]{1}[0-9]{7,8}$/,$(this),$("#snmedico"),"El formato debe ser 9999");
	});
	
	
//FIN DE VALIDACION DE DATOS

//CONTROL DE BOTONES

$("#incluir").on("click",function(){
	if(validarenvio()){
		$("#accion").val("incluir");	
		$("#f").submit();
	}
});
$("#modificar").on("click",function(){
	if(validarenvio()){
		$("#accion").val("modificar");	
		$("#f").submit();
	}
});
$("#eliminar").on("click",function(){
	if(validarkeyup(/^[VE]{1}[-]{1}[0-9]{7,8}$/,$("#cedula"),
		$("#scedula"),"El formato debe ser V-9999999 o E-9999999")==0){
	    muestraMensaje("La cedula debe coincidir con el formato <br/>"+ 
						"VE-000000000");	
		
	}
	else{	
		$("#accion").val("eliminar");	
		$("#f").submit();
	}
	
});
//FIN DE CONTROL DE BOTONES	


	
	
});

//Validación de todos los campos antes del envio
function validarenvio(){
	if(validarkeyup(/^[VE]{1}[-]{1}[0-9]{7,8}$/,$("#cedula"),
		$("#scedula"),"El formato debe ser V-9999999 o E-9999999")==0){
	    muestraMensaje("La cedula debe coincidir con el formato <br/>"+ 
						"VE-000000000");	
		return false;					
	}	
	else if(validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}$/,
		$("#apellidos"),$("#sapellidos"),"Solo letras entre 3 y 15 caracteres")==0){
		muestraMensaje("El Apellido debe contener entre 3 y 15 letras");
		return false;
	}
	else if(validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}$/,
		$("#nombres"),$("#snombres"),"Solo letras entre 3 y 15 caracteres")==0){
		muestraMensaje("El Nombre debe contener entre 3 y 15 letras");
		return false;
	}
	else if(validarkeyup(/^[A-Za-z0-9,#\b\s\u00f1\u00d1\u00E0-\u00FC-]{6,35}$/,
		$("#direccion"),$("#sdireccion"),"Solo letras y/o numeros entre 6 y 35 caracteres")==0){
		muestraMensaje("La direccion debe ser <br/>"+
					   "Solo letras y/o numeros entre 6 y 35 caracteres");
		return false;				
	}
	else if(validarkeyup(/^[0-9]{4}[-]{1}[0-9]{7,8}$/,
		$("#nmedico"),$("#snmedico"),"El formato debe ser 9999")==0){
		 muestraMensaje("El número de medico debe ser <br/>"+
					   "9999");	 
	     return false;
	}
	else if(validarkeyup(/^[A-Za-z_\u00f1\u00d1\u00E0-\u00FC-]{3,15}[@]{1}[A-Za-z0-9]{3,8}[.]{1}[A-Za-z]{2,3}$/,
		$("#correo"),$("#scorreo"),"El formato debe ser alguien@servidor.com")==0){
		muestraMensaje("El Correo debe ser <br/>"+
					   "alguien@servidor.com");	 
		 return false;
	}
	return true;
}


//Funcion que muestra el modal con un mensaje
function muestraMensaje(mensaje){
	$("#contenidodemodal").html(mensaje);
			$("#mostrarmodal").modal("show");
			setTimeout(function() {
					$("#mostrarmodal").modal("hide");
			},4000);
}


//Función para validar por Keypress
function validarkeypress(er,e){
	
	key = e.keyCode;
	
	
    tecla = String.fromCharCode(key);
	
	
    a = er.test(tecla);
	
    if(!a){
	
		e.preventDefault();
    }
	
    
}
//Función para validar por keyup
function validarkeyup(er,etiqueta,etiquetamensaje,
mensaje){
	a = er.test(etiqueta.val());
	if(a){
		etiquetamensaje.text("");
		return 1;
	}
	else{
		etiquetamensaje.text(mensaje);
		return 0;
	}
}