<?php
if(is_file("vista/".$pagina.".php")){ 
	if(!empty($_POST)){
		
		$usuario = $_POST['usuario'];
		$clave = $_POST['clave'];
		
		if($usuario == "admin" and $clave="123456"){
			session_start();
			$_SESSION['nivel'] = 'admin';
			header("Location: . ");
		}
		elseif($usuario == "user" and $clave == "123456"){
			session_start();
			$_SESSION['nivel'] = 'user';  
			header("Location: . ");
		}
		else{
			$mensaje = "Datos erroneos, los permitidos son <br/>
			usuario = admin  clave = 123456 <br/>
			usuario = user clave = 123456";
		}
		
	}
	
	require_once("vista/".$pagina.".php"); 
}
else{
	echo "pagina en construccion";
}
?>
