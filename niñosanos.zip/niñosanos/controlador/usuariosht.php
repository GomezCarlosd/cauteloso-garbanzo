<?php
  
//llamada al archivo que contiene la clase
//usuarios, en ella estara el codigo que me //permitirá
//guardar, consultar y modificar dentro de mi base //de datos
require_once('modelo/usuariosht.php');

//lo primero que se debe hacer es verificar al //igual que en la vista que exista el archivo
if (!is_file("modelo/".$pagina.".php")){
	//alli pregunte que si no es archivo se niega //con !
	//si no existe envio mensaje y me salgo
	echo "Falta definir la clase ".$pagina;
	exit;
}  
  
  if(is_file("vista/".$pagina.".php")){
	  
	  //bien si estamos aca es porque existe la //vista y la clase
	  //por lo que lo primero que debemos hace es //realizar una instancia de la clase
	  //instanciar es crear una variable local, //que contiene los metodos de la clase
	  //para poderlos usar
	  
	  $o = new usuariosht(); //ahora nuestro objeto //se llama $o y es una copia en memoria de la
	  //clase usuarios
	  
	  if(!empty($_POST)){
		  
		  //como ya sabemos si estamos aca es //porque se recibio alguna informacion
		  //de la vista, por lo que lo primero que //debemos hacer ahora que tenemos una 
		  //clase es guardar esos valores en ella //con los metodos set
		  
		  $o->set_cedula($_POST['cedula']);
		  $o->set_usuario($_POST['usuario']);
		  $o->set_clave($_POST['clave']);
		  
		  
		  if(isset($_POST['incluir'])){
			$mensaje =  $o->incluir();
		  }
		  elseif(isset($_POST['modificar'])){
			$mensaje =  $o->modificar();
			
		  }
		  elseif(isset($_POST['eliminar'])){
			$mensaje =  $o->eliminar();
			
		  }
	  }
	  
	  require_once("vista/".$pagina.".php"); 
  }
  else{
	  echo "pagina en construccion";
  }
?>
