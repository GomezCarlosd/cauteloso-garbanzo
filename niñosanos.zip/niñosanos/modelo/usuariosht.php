<?php
//llamda al archivo que contiene la clase
//datos, en ella posteriormente se colcora el codigo
//para enlazar a su base de datos
require_once('modelo/datos.php');

//declaracion de la clase usuarios que hereda de la clase datos
//la herencia se declara con la palabra extends y no es mas 
//que decirle a esta clase que puede usar los mismos metodos
//que estan en la clase de dodne hereda (La padre) como sir fueran de el

class usuariosht extends datos{
	//el primer paso dentro de la clase
	//sera declarar los atributos (variables) que describen la clase
	//para nostros no es mas que colcoar los inputs (controles) de
	//la vista como variables aca
	//cada atributo debe ser privado, es decir, ser visible solo dentro de la
	//misma clase, la forma de colcoarlo privado es usando la palabra private
	
	private $cedula; //recuerden que en php, las variables no tienen tipo predefinido
	private $usuario;
	private $clave;
	
	//Ok ya tenemos los atributos, pero como son privados no podemos acceder a ellos desde fueran
	//por lo que debemos colcoar metodos (funciones) que me permitan leer (get) y colocar (set)
	//valores en ello, esto es  muy mal llamado geters y seters por si alguien se los pregunta
	
	function set_cedula($valor){
		$this->cedula = $valor; //fijencen como se accede a los elementos dentro de una clase
		//this que singnifica esto es decir esta clase luego -> simbolo que indica que apunte
		//a un elemento de this, es decir esta clase
		//luego el nombre del elemento sin el $
	}
	//lo mismo que se hizo para cedula se hace para usuario y clave
	
	function set_usuario($valor){
		$this->usuario = $valor;
	}
	
	function set_clave($valor){
		$this->clave = $valor;
	}
	
	//ahora la misma cosa pero para leer, es decir get
	
	function get_cedula(){
		return $this->cedula;
	}
	
	function get_clave(){
		return $this->clave;
	}
	
	function get_usuario(){
		return $this->usuario;
	}
	
	//Lo siguiente que demos hacer es crear los metodos para incluir, consultar y eliminar
	
	function incluir(){
		//aca iran las instrucciones sql, por lo pronto solo retornaremos un mensaje
		return "Usted va a incluir <br/>".$this->cedula.
				"<br/>".$this->usuario."<br/>".$this->clave;
	}
	
	function modificar(){
		//aca iran las instrucciones sql, por lo pronto solo retornaremos un mensaje
		return "Usted va a modificar <br/>".$this->cedula.
				"<br/>".$this->usuario."<br/>".$this->clave;
	}
	
	function eliminar(){
		//aca iran las instrucciones sql, por lo pronto solo retornaremos un mensaje
		return "Usted va a eliminar <br/>".$this->cedula;
	}
	
}
?>